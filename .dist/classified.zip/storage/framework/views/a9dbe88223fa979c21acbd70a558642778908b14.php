<!DOCTYPE html>
<html>
<head></head>
<body>
<a href="model/create">Create</a>
      <table>
                <thead>
                <th>model</th>
                <th>category</th>
                
                </thead>
                <tbody>
                

                <?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orgs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                            <td class="district"><?php echo e($orgs->name); ?></td>
                            <?php $__currentLoopData = $orgs->caty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td class="district"><?php echo e($model->caty); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                
                
                
              
                </tbody>
                        </table>
</body></html><?php /**PATH C:\xampp\htdocs\classified\resources\views/category/index.blade.php ENDPATH**/ ?>