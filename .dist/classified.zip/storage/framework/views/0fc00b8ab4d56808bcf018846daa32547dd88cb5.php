<!DOCTYPE html>
<html>
<head>
</head>
<body>
<a href="location/create">Create</a>

                <table>
                <thead>
                <th>Location</th>
                <th>Dist</th>
                </thead>
                <tbody>
                

                <?php $__currentLoopData = $locate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orgs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                            <td class="district"><?php echo e($orgs->name); ?></td>
                            <?php $__currentLoopData = $orgs->district; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td class="district"><?php echo e($dis->district); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                
                
                
              
                </tbody>
                        </table>

                        </body></html><?php /**PATH C:\xampp\htdocs\classified\resources\views/location/index.blade.php ENDPATH**/ ?>