<!DOCTYPE html>
<html>
<head>
<body>
<form action="<?php echo e(url('model/store')); ?>" method="post">
<?php echo e(csrf_field()); ?>




<label>category</label>
<select name="category">
<?php $__currentLoopData = $caty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orgs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($orgs->id); ?>"><?php echo e($orgs->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
 
<br><br>
<label>model</label>
<input type="text" name="model" >
<input type="submit"value="submit">
</form>
</body>
</html>
</form></body></head></html><?php /**PATH C:\xampp\htdocs\classified\resources\views/category/create.blade.php ENDPATH**/ ?>