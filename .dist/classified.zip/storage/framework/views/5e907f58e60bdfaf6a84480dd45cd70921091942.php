<!DOCTYPE html>
<html>
<head></head>
<body>
<form   action="<?php echo e(url('location/store')); ?>" method="post"   >
                          <?php echo e(csrf_field()); ?>



<label>district</label>
<select name="district">
<?php $__currentLoopData = $district; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orgs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($orgs->id); ?>"><?php echo e($orgs->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
 
<br><br>
<label>location</label>
<input type="text" name="location" >
<input type="submit"value="submit">
</form>
</body>
</html><?php /**PATH C:\xampp\htdocs\classified\resources\views/location/create.blade.php ENDPATH**/ ?>