<?php

use Illuminate\Support\Facades\Route;
use App\Models\Location;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('');
   
});

Route::resource('location', 'App\Http\Controllers\LocationController');
Route::post('location/store', 'App\Http\Controllers\LocationController@store');

Route::resource('model', 'App\Http\Controllers\ModelController');
Route::post('model/store', 'App\Http\Controllers\ModelController@store');


Route::get('post-add', 'App\Http\Controllers\ToaddController@get_post');
Route::get('get-location', function() {

    if (Request::get('location_id')) {
        return App\Models\Location::where('location.id', Request::get('location_id'))->first();
    }

});

