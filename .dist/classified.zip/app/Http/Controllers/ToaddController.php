<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\District;
use App\Models\Category;

class ToaddController extends Controller
{
    public function get_post()
    {
        $dist=District::get();
        $caty=Category::get();
        return view('front-ent.post-ad',['caty'=>$caty,'dist'=>$dist]);
    }
    public function store()
    {

    }
}
