<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ToAdd extends Model
{
    protected $table = 'to_add_post';
    use HasFactory;
}
