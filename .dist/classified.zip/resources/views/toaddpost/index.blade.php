<!DOCTYPE html>
<html>
<head></head>
<body>
<table>
<thead>
<th>foradd</th>
<th>Description</th>
<th>District</th>
<th>location</th>
<th>phone number</th>
<th>category</th>
<th>model</th>
<th>Condition</th>
<th>Color</th>
<th>Warranty</th>
<th>Price</th>
<th>Damages on Devices</th>
<th>Damage Details</th>
<th>Image</th>
<th>Battery Health</th>
</thead>
<tbody>
</tbody>

</table>

</body></html>