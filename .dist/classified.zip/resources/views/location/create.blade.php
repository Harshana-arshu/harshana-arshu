<!DOCTYPE html>
<html>
<head></head>
<body>
if($validator->fails()) {
    return Redirect::back('location.index')->withErrors($validator);
}

<form   action="{{url('location/store')}}" method="post"   >
                          {{csrf_field()}}


<label>district</label>
<select name="district">
@foreach($district as $orgs)
<option value="{{$orgs->id}}">{{$orgs->name}}</option>
@endforeach
</select>
 
<br><br>
<label>location</label>
<input type="text" name="location" >
<input type="submit"value="submit">
</form>
</body>
</html>